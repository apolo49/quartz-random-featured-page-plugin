// ============================================================================
// Random Featured Article Plugin - Client-Side Logic
// ============================================================================
// This script selects a featured article from the site index each day
// using a seeded random number generator based on the current date.
// Similar to Wikipedia's featured article of the day.
// ============================================================================
/* eslint-disable no-restricted-syntax */

interface ContentItem {
  slug: string;
  title: string;
  excerpt?: string;
  description?: string;
}

interface QuartzWindowExtension {
  contentIndex?: ContentItem[];
  addCleanup?: (fn: () => void) => void;
}

/**
 * Seeded random number generator using a simple algorithm
 * Based on the date seed to ensure the same article appears all day
 */
function seededRandom(seed: number): number {
  const x = Math.sin(seed++) * 10000;
  return x - Math.floor(x);
}

/**
 * Get today's date as a seed (YYYY-MM-DD format)
 * This ensures the same article is featured for the entire day
 */
function getDaySeed(): number {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  const dateStr = `${year}${month}${day}`;
  return Number.parseInt(dateStr, 10);
}

/**
 * Check if current URL matches any of the activation URLs
 */
function isActivePage(currentUrl: string, activateUrls: string[]): boolean {
  const url = currentUrl.toLowerCase();
  return activateUrls.some((activateUrl) => {
    const normalized = activateUrl.toLowerCase();
    return url === normalized || url === normalized.replace(/\/$/, "");
  });
}

/**
 * Escape HTML special characters to prevent XSS
 */
function escapeHtml(text: string): string {
  const map: Record<string, string> = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;",
  };
  return text.replace(/[&<>"']/g, (char) => map[char] || char);
}

/**
 * Fallback function to fetch index from file
 */
async function populateWithFallback(
  featuredDiv: HTMLElement,
  daySeed: number,
  debug: boolean,
): Promise<void> {
  try {
    // Try to fetch the content index from the site
    const response = await fetch("./index.json");
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = (await response.json()) as
      | {
          content?: ContentItem[];
        }
      | ContentItem[];
    const contentIndex = Array.isArray(data) ? data : data.content || [];

    if (debug) {
      console.log("[RandomFeaturedArticle] Loaded index from file:", contentIndex.length, "items");
    }

    // Filter and select article
    const articles = contentIndex.filter((item: ContentItem) => {
      const slug = item.slug || "";
      const title = item.title || "";
      return !slug.endsWith("index") && title && title.length > 0;
    });

    if (articles.length > 0) {
      const randomIndex = Math.floor(seededRandom(daySeed) * articles.length);
      const featuredArticle = articles[randomIndex];
      if (!featuredArticle) return;

      const slug = featuredArticle.slug || "";
      const title = featuredArticle.title || "Featured Article";
      const excerpt =
        featuredArticle.excerpt ||
        featuredArticle.description ||
        "Check out this article from our collection!";

      const html = `
        <div class="featured-article-content">
          <h2 class="featured-article-title">
            <a href="${slug}" class="featured-article-link">${escapeHtml(title)}</a>
          </h2>
          <p class="featured-article-excerpt">${escapeHtml(excerpt)}</p>
          <a href="${slug}" class="featured-article-button">Read More →</a>
        </div>
      `;

      featuredDiv.innerHTML = html;

      if (debug) {
        console.log("[RandomFeaturedArticle] Featured article populated from fallback");
      }
    }
  } catch (error) {
    if (debug) {
      console.error("[RandomFeaturedArticle] Error loading index:", error);
    }
  }
}

/**
 * Main function to populate featured article
 */
function populateFeaturedArticle(): void {
  // Read config from the init element
  const initElement = document.getElementById("featured-article-init");
  if (!initElement) {
    console.warn("[RandomFeaturedArticle] Init element not found");
    return;
  }

  const pageTitle =
    initElement.getAttribute("data-page-title") ||
    "Welcome to Tara - The World of Solara | Tara, the world of Solara";
  const activateUrlsStr = initElement.getAttribute("data-activate-urls") || "";
  const debug = initElement.getAttribute("data-debug") === "true";
  const activateUrls = activateUrlsStr.split("|").filter((url) => url.length > 0);

  if (debug) {
    console.log("[RandomFeaturedArticle] Initializing...", {
      currentUrl: window.location.href,
      pageTitle: document.title,
      expectedPageTitle: pageTitle,
      activateUrls,
    });
  }

  // Check if we're on the correct page
  const isCorrectPage =
    document.title === pageTitle && isActivePage(window.location.href, activateUrls);

  if (!isCorrectPage) {
    if (debug) {
      console.log("[RandomFeaturedArticle] Not on correct page, skipping");
    }
    return;
  }

  if (debug) {
    console.log("[RandomFeaturedArticle] On correct page, proceeding...");
  }

  // Look for the featured article div
  const featuredDiv = document.getElementById("featured-article");
  if (!featuredDiv) {
    if (debug) {
      console.warn("[RandomFeaturedArticle] Could not find #featured-article div");
    }
    return;
  }

  // Get the content index from Quartz
  // The index is typically loaded and available in the window object
  const quartzWindow = window as unknown as QuartzWindowExtension;
  const contentIndex = quartzWindow.contentIndex;

  if (!contentIndex || !Array.isArray(contentIndex)) {
    if (debug) {
      console.warn("[RandomFeaturedArticle] Content index not available", {
        contentIndex: typeof contentIndex,
      });
    }

    // Fallback: try to fetch from the index file
    const daySeed = getDaySeed();
    populateWithFallback(featuredDiv, daySeed, debug);
    return;
  }

  if (debug) {
    console.log("[RandomFeaturedArticle] Found content index with", contentIndex.length, "items");
  }

  // Filter out index pages and non-article pages
  const articles = contentIndex.filter((item: ContentItem) => {
    const slug = item.slug || "";
    const title = item.title || "";

    // Exclude index pages and pages without titles
    return !slug.endsWith("index") && title && title.length > 0;
  });

  if (articles.length === 0) {
    if (debug) {
      console.warn("[RandomFeaturedArticle] No articles found in index");
    }
    return;
  }

  if (debug) {
    console.log("[RandomFeaturedArticle] Found", articles.length, "articles");
  }

  // Get today's seed and select a featured article
  const daySeed = getDaySeed();
  const randomIndex = Math.floor(seededRandom(daySeed) * articles.length);
  const featuredArticle = articles[randomIndex];
  if (!featuredArticle) return;

  if (debug) {
    console.log("[RandomFeaturedArticle] Selected article:", {
      seed: daySeed,
      randomIndex,
      article: featuredArticle,
    });
  }

  // Create HTML for the featured article
  const slug = featuredArticle.slug || "";
  const title = featuredArticle.title || "Featured Article";
  const excerpt =
    featuredArticle.excerpt ||
    featuredArticle.description ||
    "Check out this article from our collection!";

  const html = `
    <div class="featured-article-content">
      <h2 class="featured-article-title">
        <a href="${slug}" class="featured-article-link">${escapeHtml(title)}</a>
      </h2>
      <p class="featured-article-excerpt">${escapeHtml(excerpt)}</p>
      <a href="${slug}" class="featured-article-button">Read More →</a>
    </div>
  `;

  featuredDiv.innerHTML = html;

  if (debug) {
    console.log("[RandomFeaturedArticle] Featured article populated successfully");
  }
}

/**
 * Handle navigation events
 */
function handleNavigation(): void {
  // Use a small delay to ensure DOM is ready
  setTimeout(populateFeaturedArticle, 100);
}

// Initialize when the page loads or when navigation occurs
// Listen to Quartz navigation events
document.addEventListener("nav", handleNavigation);

// Register cleanup with Quartz's cleanup system if available
const quartzWindow = window as unknown as QuartzWindowExtension;
if (quartzWindow.addCleanup) {
  quartzWindow.addCleanup(() => {
    document.removeEventListener("nav", handleNavigation);
  });
}

// Also run on initial page load
populateFeaturedArticle();
